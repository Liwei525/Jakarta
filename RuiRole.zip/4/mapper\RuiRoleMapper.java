package 4.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import 4.po.RuiRolePO;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * RuiRoleMapper
 *
 * @author laotree
 * @Date 2018/6/1 下午6:01:47
 */
public interface RuiRoleMapper extends BaseMapper<RuiRolePO>{

}