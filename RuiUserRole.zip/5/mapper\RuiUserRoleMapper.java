package 5.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import 5.po.RuiUserRolePO;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * RuiUserRoleMapper
 *
 * @author laotree
 * @Date 2018/6/1 下午6:06:32
 */
public interface RuiUserRoleMapper extends BaseMapper<RuiUserRolePO>{

}